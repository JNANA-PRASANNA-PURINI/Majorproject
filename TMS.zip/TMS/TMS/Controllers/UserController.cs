﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using TMS.Models;

namespace TMS.Controllers
{
    public class UserController : Controller
    {
        // GET: EmployeeController
        public ActionResult Index()
        {
            return View();
        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        public ActionResult UserCreated()
        {
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                User userObj = new User();
                userObj.UserId = collection["txtID"].ToString();
                userObj.FirstName = collection["txtFirstName"].ToString();
                userObj.LastName = collection["txtLastName"].ToString();
                userObj.Email = collection["txtEmailId"].ToString();
                userObj.Gender = collection["inlineRadioOptions"].ToString();
                userObj.Occupation = collection["drpDownOccupation"].ToString();
                userObj.PassWord = collection["txtPwd"].ToString();
                userObj.Address = collection["txtAddress"].ToString();
                userObj.Department = collection["drpDownDepartment"].ToString();

                string query = "INSERT INTO UserDetails (UserId, FirstName, LastName, Email, Gender,  Occupation, UserAddress, UserPassWord, Department)";
                query += " VALUES (@UserId, @FirstName, @LastName, @Email, @Gender, @Occupation, @Address,@PassWord, @Department)";

                String connectionString = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";

                SqlConnection myConnection = new SqlConnection(connectionString);

                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.Parameters.AddWithValue("@UserId", userObj.UserId);
                myCommand.Parameters.AddWithValue("@FirstName", userObj.FirstName);
                myCommand.Parameters.AddWithValue("@LastName", userObj.LastName);
                myCommand.Parameters.AddWithValue("@Email", userObj.Email);
                myCommand.Parameters.AddWithValue("@Gender", userObj.Gender);
                myCommand.Parameters.AddWithValue("@Occupation", userObj.Occupation);
                myCommand.Parameters.AddWithValue("@Address", userObj.Address);
                myCommand.Parameters.AddWithValue("@PassWord", userObj.PassWord);
                myCommand.Parameters.AddWithValue("@Department", userObj.Department);
                // ... other parameters
                myCommand.ExecuteNonQuery();

                return RedirectToAction(nameof(UserCreated));
            }
            catch(Exception ex)
            {
                return RedirectToAction(nameof(Index));
            }
        }

        // GET: EmployeeController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // GET: UserController/ForGotPassWord
        public ActionResult ForGotPassWord()
        {
            return View();
        }

        public ActionResult PassWordCreated()
        {
            return View();
        }

        public ActionResult UpdatePassWord(IFormCollection collection)
        {
            string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "UPDATE UserDetails SET UserPassword =@UserPassword WHERE Email = @Email and UserId = @UserId;";
                SqlCommand myCommand = new SqlCommand(oString, myConnection);
                myCommand.Parameters.AddWithValue("@Email", collection["Email"].ToString());
                myCommand.Parameters.AddWithValue("@UserId", collection["UserId"].ToString());
                myCommand.Parameters.AddWithValue("@UserPassword", collection["Password"].ToString());
                
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }
            return RedirectToAction("PassWordCreated");
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
