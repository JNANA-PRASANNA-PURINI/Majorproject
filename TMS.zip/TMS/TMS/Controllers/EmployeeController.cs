﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualBasic;
using System.Collections.Generic;
using System.Data.SqlClient;
using TMS.Models;

namespace TMS.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: EmployeeController
        public ActionResult Index()
        {
            string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
            RequestDetails requestDetails = new RequestDetails();
            List<RequestDetails> lstRequestDetails = new List<RequestDetails>();

            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "Select * from RequestDetails where AssignedTo=@UserId";
                SqlCommand oCmd = new SqlCommand(oString, myConnection);
                oCmd.Parameters.AddWithValue("@UserId", HttpContext.Session.GetString("userId"));
                myConnection.Open();
                using (SqlDataReader oReader = oCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        lstRequestDetails.Add(new RequestDetails()
                        {
                            UserId = oReader["UserId"].ToString(),
                            RequestId = oReader["RequestId"].ToString(),
                            RequestDescription = oReader["RequestDescription"].ToString(),
                            RequestType = oReader["RequestType"].ToString(),
                            RequestStatus = oReader["RequestStatus"].ToString(),
                            AssignedTo = oReader["AssignedTo"].ToString(),
                            Comments = oReader["Comments"].ToString()
                        });
                    }

                    myConnection.Close();
                }
            }

            return View(lstRequestDetails);
        }

        // GET: EmployeeController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5
        public ActionResult Edit(string RequestId, string RequestStatus,string UserId,string RequestType, string AssignedTo)
        {
            return View();
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(string RequestId, IFormCollection collection)
        {
            try
            {
                string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
                using (SqlConnection myConnection = new SqlConnection(con))
                {
                    string oString = "UPDATE RequestDetails SET RequestStatus = @RequestStatus, Comments=@Comments WHERE RequestId = @RequestId;";
                    SqlCommand myCommand = new SqlCommand(oString, myConnection);
                    myCommand.Parameters.AddWithValue("@RequestStatus", collection["RequestStatus"].ToString());
                    myCommand.Parameters.AddWithValue("@RequestId", RequestId);
                    myCommand.Parameters.AddWithValue("@Comments", collection["Comments"].ToString());

                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
