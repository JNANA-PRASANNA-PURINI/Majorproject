﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System;
using System.Diagnostics;
using System.Xml.Linq;
using TMS.Models;
using Microsoft.AspNetCore.Mvc.Infrastructure;

namespace TMS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Login(IFormCollection collection)
        {
            string userName = collection["txtUserName"].ToString();
            string passWord = collection["txtPassWord"].ToString();
            var con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
            string userId = "";
            string occupation = "";
            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "Select * from UserDetails where Email=@UserName and UserPassWord=@passWord";
                SqlCommand oCmd = new SqlCommand(oString, myConnection);
                oCmd.Parameters.AddWithValue("@UserName", userName);
                oCmd.Parameters.AddWithValue("@PassWord", passWord);
                myConnection.Open();
                using (SqlDataReader oReader = oCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        userId = oReader["UserId"].ToString();
                        occupation = oReader["Occupation"].ToString();
                        HttpContext.Session.SetString("userId", userId);
                        HttpContext.Session.SetString("Occupation", occupation);
                        HttpContext.Session.SetString("FirstName", oReader["FirstName"].ToString());
                    }

                    myConnection.Close();
                }
            }
            if(occupation == "Student")
            {
                return RedirectToAction("Index",
                        "Student");
            }
            if (occupation == "Employee")
            {
                return RedirectToAction("Index",
                        "Employee");
            }
            if (occupation == "Admin")
            {
                return RedirectToAction("Index",
                        "Admin");
            }
            else
            {
                return View("UserNotFound");
            }
            
        }

        public IActionResult UserNotFound()
        {
            return View();
        }

        public IActionResult LogOut()
        {
            HttpContext.Session.Clear();
            return View("Index");
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}