﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using System.Drawing;
using TMS.Models;

namespace TMS.Controllers
{
    public class StudentController : Controller
    {
        // GET: StudentController
        public ActionResult Index()
        {

            string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
            RequestDetails requestDetails = new RequestDetails();
            List<RequestDetails> lstRequestDetails = new List<RequestDetails>();

            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "Select * from RequestDetails where UserId=@UserId";
                SqlCommand oCmd = new SqlCommand(oString, myConnection);
                oCmd.Parameters.AddWithValue("@UserId", HttpContext.Session.GetString("userId"));
                myConnection.Open();
                using (SqlDataReader oReader = oCmd.ExecuteReader())
                {
                    while (oReader.Read())
                    {
                        lstRequestDetails.Add(new RequestDetails() {
                        UserId = oReader["UserId"].ToString(),
                        RequestId = oReader["RequestId"].ToString(),
                        RequestDescription = oReader["RequestDescription"].ToString(),
                        RequestType = oReader["RequestType"].ToString(),
                        RequestStatus = oReader["RequestStatus"].ToString(),
                        AssignedTo = oReader["AssignedTo"].ToString(),
                        Comments = oReader["Comments"].ToString()
                    });
                    }
           
                    myConnection.Close();
                }
            }

            return View(lstRequestDetails);
        }

        // GET: StudentController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: StudentController/Create
        public ActionResult Create()
        {
            return View();
        }

        public ActionResult RequestCreated()
        {
            return View();
        }

        // POST: StudentController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult CreateRequest(IFormCollection collection)
        {
            try
            {
                RequestDetails requestObj = new RequestDetails();
                requestObj.UserId = collection["UserId"].ToString();
                requestObj.RequestId = Guid.NewGuid().ToString();
                requestObj.RequestType = collection["RequestType"].ToString();
                requestObj.RequestDescription = collection["RequestDescription"].ToString();
                requestObj.RequestStatus = "Open";
                requestObj.AssignedTo = "NA";
                requestObj.Comments = collection["Comments"].ToString();

                string query = "INSERT INTO RequestDetails (UserId, RequestId, RequestType, RequestDescription, RequestStatus,  AssignedTo, Comments)";
                query += " VALUES (@UserId, @RequestId, @RequestType, @RequestDescription, @RequestStatus, @AssignedTo, @Comments)";

                String connectionString = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";

                SqlConnection myConnection = new SqlConnection(connectionString);

                myConnection.Open();
                SqlCommand myCommand = new SqlCommand(query, myConnection);
                myCommand.Parameters.AddWithValue("@UserId", requestObj.UserId);
                myCommand.Parameters.AddWithValue("@RequestId", requestObj.RequestId);
                myCommand.Parameters.AddWithValue("@RequestType", requestObj.RequestType);
                myCommand.Parameters.AddWithValue("@RequestStatus", requestObj.RequestStatus);
                myCommand.Parameters.AddWithValue("@RequestDescription", requestObj.RequestDescription);
                myCommand.Parameters.AddWithValue("@AssignedTo", requestObj.AssignedTo);
                myCommand.Parameters.AddWithValue("@Comments", requestObj.Comments);

                // ... other parameters
                myCommand.ExecuteNonQuery();

                return RedirectToAction(nameof(RequestCreated));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Edit/5
        public ActionResult Edit(string RequestId, string RequestStatus,string RequestDescription, string UserId, string RequestType, string AssignedTo)
        {
            return View();
        }

        // POST: StudentController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(IFormCollection collection)
        {
            try
            {
                string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
                using (SqlConnection myConnection = new SqlConnection(con))
                {
                    string oString = "UPDATE RequestDetails SET RequestDescription = @RequestDescription, Comments=@Comments WHERE RequestId = @RequestId;";
                    SqlCommand myCommand = new SqlCommand(oString, myConnection);
                    myCommand.Parameters.AddWithValue("@RequestDescription", collection["RequestDescription"].ToString());
                    myCommand.Parameters.AddWithValue("@RequestId", collection["RequestId"].ToString());
                    myCommand.Parameters.AddWithValue("@Comments", collection["Comments"].ToString());

                    myConnection.Open();
                    myCommand.ExecuteNonQuery();
                    myConnection.Close();
                }
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: StudentController/Delete/5
        public ActionResult Delete(string id)
        {
            string con = "Server=localhost\\SQLEXPRESS;Database=TMS;Trusted_Connection=True;";
            
            using (SqlConnection myConnection = new SqlConnection(con))
            {
                string oString = "DELETE FROM RequestDetails WHERE RequestId=@UserId";
                SqlCommand myCommand = new SqlCommand(oString, myConnection);
                myCommand.Parameters.AddWithValue("@UserId", id);
                myConnection.Open();
                myCommand.ExecuteNonQuery();
                myConnection.Close();
            }

            return View();
        }

        // POST: StudentController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
