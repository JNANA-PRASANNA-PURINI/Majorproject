﻿using TMS.Models;

namespace TMS.Models
{
    public class RequestDetails
    {
        public string? UserId { get; set; }
        public string? RequestType { get; set; }
        public string? RequestDescription { get; set; }
        public string? RequestId { get; set; }
        public string? RequestStatus { get; set; }

        public string? AssignedTo { get; set; }

        public string? Comments { get; set; }
        
    }
}
